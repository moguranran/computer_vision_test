import scipy.misc
lena = scipy.misc.lena()

from scipy.misc import imsave 
imsave('test.jpg',lena)



